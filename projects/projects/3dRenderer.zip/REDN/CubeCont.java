import static java.lang.System.*;

import java.sql.Array;
import java.util.Arrays;

public class CubeCont {
	////////////Variables/////////////
	private double[] camP = new double[3];
	private double[][] points = new double[8][3];
	private int[][] lines = new int[12][2];
	private double[][] rotations = new double[1][3];
	private double[][] translations = new double[1][3];
	private double zNear;
	private int width = 800;
	private int height = 600;
	
	public CubeCont() {
		
		points[0][0] = 1;
		points[0][1] = 1;
		points[0][2] = 1;
		
		points[1][0] = -1;
		points[1][1] = 1;
		points[1][2] = 1;
		
		points[2][0] = -1;
		points[2][1] = -1;
		points[2][2] = 1;
		
		points[3][0] = -1;
		points[3][1] = -1;
		points[3][2] = -1;
		
		points[4][0] = -1;
		points[4][1] = 1;
		points[4][2] = -1;
		
		points[5][0] = 1;
		points[5][1] = -1;
		points[5][2] = -1;
		
		points[6][0] = 1;
		points[6][1] = 1;
		points[6][2] = -1;
		
		points[7][0] = 1;
		points[7][1] = -1;
		points[7][2] = 1;

		lines[0][0] = 0;
		lines[0][1] = 1;
		
		lines[1][0] = 1;
		lines[1][1] = 4;
		
		lines[2][0] = 4;
		lines[2][1] = 6;
		
		lines[3][0] = 6;
		lines[3][1] = 0;
		
		lines[4][0] = 0;
		lines[4][1] = 7;
		
		lines[5][0] = 1;
		lines[5][1] = 2;
		
		lines[6][0] = 4;
		lines[6][1] = 3;
		
		lines[7][0] = 5;
		lines[7][1] = 6;
		
		lines[8][0] = 5;
		lines[8][1] = 3;
		
		lines[9][0] = 3;
		lines[9][1] = 2;
		
		lines[10][0] = 7;
		lines[10][1] = 2;
		
		lines[11][0] = 7;
		lines[11][1] = 6;
	}
	
	
	public CubeCont(double rotX, double rotY, double rotZ, double transX, double transY, double transZ) {
		stSet(rotX, rotY, rotZ, transX, transY, transZ);
	}
	
	public void stSet(double rotX, double rotY, double rotZ, double transX, double transY, double transZ) {
		rotations[0][0] = deg2rad(rotX);
		rotations[0][1] = deg2rad(rotY);
		rotations[0][2] = deg2rad(rotZ);
		
		translations[0][0] = transX;
		translations[0][1] = transY;
		translations[0][2] = transZ;
		
		camP[0] = 11.001;
		camP[1] = 11.01;
		camP[2] = -.1;
		
		zNear = 1;
	}
	////////////Processes////////////
	public int[] getPoint(int num) {
		
		return WorldToRaster(points[num]);
	}
	
	public int[] getLine(int num) {
		int x1,y1,x2,y2;
		x1 = (int) getPoint(lines[num][0])[0];
		y1 = (int) getPoint(lines[num][0])[1];
		x2 = (int) getPoint(lines[num][1])[0];
		y2 = (int) getPoint(lines[num][1])[1];
		
		return new int[]{x1,y1,x2,y2};
	}
	////Math
	public static double[][] MatInverse(double[][] mat) {

		double[][] matMoM = {{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}}; //Matrix of Minors
		double[][] matMoC = {{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}}; //Matrix of Cofactors
		double[][] matA = {{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}}; //Adjugate
		double[][] matI = {{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
		
		double det;
		int detR = 0;
		int detC = 0;
		double[][] matD = {{0,0,0},{0,0,0},{0,0,0}};
		
		//Loop makes matMoM
		for(int i = 0; i<mat[0].length; i++) { //Row
			for(int j = 0; j<mat.length; j++) { //Column		
				for(int o = 0; o<mat[0].length; o++) { //Row for Determinant
					for(int k = 0; k<mat.length; k++) { //Column for Determinant
						if(o != i && k != j) {
							matD[detC][detR] = mat[o][k];
							if(detC == 2) {
								detC = 0;
								detR++;
							} else {
								detC++;
							}
						}	
					}	
				}
				matMoM[i][j] = (matD[0][0]*((matD[1][1]*matD[2][2])-(matD[2][1]*matD[1][2]))) - (matD[1][0]*((matD[0][1]*matD[2][2])-(matD[2][1]*matD[0][2]))) + (matD[2][0]*((matD[0][1]*matD[1][2])-(matD[1][1]*matD[0][2])));
				detC = 0;
				detR = 0;
			}
		}
		
		//Calculate the determinant
		det = (mat[0][0]*matMoM[0][0]) - (mat[0][1]*matMoM[0][1]) + (mat[0][2]*matMoM[0][2]) - (mat[0][3]*matMoM[0][3]);
		if(det == 0)
		{
			System.out.println("Determinant = 0.0, returning original matrix.");
			return mat;
		}
		
		//Loop makes matMoc
		for(int i = 0; i<mat.length; i++) { //Row
			for(int j = 0; j <mat.length; j++) { //Column
				if(j%2 == 0 || j == 0) {
					if(i%2 != 0 && i != 0) {
						matMoC[i][j] = matMoM[i][j]*-1; 
					} else {
						matMoC[i][j] = matMoM[i][j];
					}
				} else {
					if(i%2 == 0 || i == 0) {
						matMoC[i][j] = matMoM[i][j]*-1; 
					} else {
						matMoC[i][j] = matMoM[i][j];
					}
				}
			}
		}
		
		//Loop for adjugate
		for(int i = 0; i<mat.length; i++) { //Row
			for(int j = 0; j<mat.length; j++) { //Column
				matA[i][j] = matMoC[j][i];
			}
		} 
		
		//Loop for the inverse
		for(int i = 0; i<mat.length; i++) { //Row
			for(int j = 0; j<mat.length; j++) { //Column
				matI[i][j] = matA[i][j]*(1.0/det);
			}
		}
		
		return matI;
	}
	
	public static double[][] MatMultS(double[][] mat1, double[][] mat2) {
		
		if(mat1[0].length != mat2.length) { //Returns null if columns of first matrix != rows of second.
			return null;
		}
		
		double[][] matM = new double[mat1.length][mat2[0].length];
		double sum = 0;
		
		
		for(int o = 0; o<mat1.length; o++) { //Rows of mat1
			for(int k = 0; k<mat2[0].length; k++) { //Columns of mat2
				
				for(int n = 0; n<mat2.length; n++) {
					sum += mat1[o][n]*mat2[n][k];
				}
				matM[o][k] = sum;
				sum = 0;
			}
			
		}
		
		return matM;
	}

	public static double deg2rad(double deg) {
		return deg*0.0174532925199;
	}
	
	public static void gaussian(double a[][], int index[]) 
	  {
	      int n = index.length;
	      double c[] = new double[n];

	// Initialize the index
	      for (int i=0; i<n; ++i) 
	          index[i] = i;

	// Find the rescaling factors, one from each row
	      for (int i=0; i<n; ++i) 
	      {
	          double c1 = 0;
	          for (int j=0; j<n; ++j) 
	          {
	              double c0 = Math.abs(a[i][j]);
	              if (c0 > c1) c1 = c0;
	          }
	          c[i] = c1;
	      }

	// Search the pivoting element from each column
	      int k = 0;
	      for (int j=0; j<n-1; ++j) 
	      {
	          double pi1 = 0;
	          for (int i=j; i<n; ++i) 
	          {
	              double pi0 = Math.abs(a[index[i]][j]);
	              pi0 /= c[index[i]];
	              if (pi0 > pi1) 
	              {
	                  pi1 = pi0;
	                  k = i;
	              }
	          }

	 // Interchange rows according to the pivoting order
	          int itmp = index[j];
	          index[j] = index[k];
	          index[k] = itmp;
	          for (int i=j+1; i<n; ++i) 	
	          {
	              double pj = a[index[i]][j]/a[index[j]][j];

	// Record pivoting ratios below the diagonal
	              a[index[i]][j] = pj;

	// Modify other elements accordingly
	              for (int l=j+1; l<n; ++l)
	                  a[index[i]][l] -= pj*a[index[j]][l];
	          }
	      }
	  }
	
	public static double[][] invert(double a[][]) 
	  {
	      int n = a.length;
	      double x[][] = new double[n][n];
	      double b[][] = new double[n][n];
	      int index[] = new int[n];
	      for (int i=0; i<n; ++i) 
	          b[i][i] = 1;

	// Transform the matrix into an upper triangle
	      gaussian(a, index);

	// Update the matrix b[i][j] with the ratios stored
	      for (int i=0; i<n-1; ++i)
	          for (int j=i+1; j<n; ++j)
	              for (int k=0; k<n; ++k)
	                  b[index[j]][k]
	                  	    -= a[index[j]][i]*b[index[i]][k];

	// Perform backward substitutions
	      for (int i=0; i<n; ++i) 
	      {
	          x[n-1][i] = b[index[n-1]][i]/a[index[n-1]][n-1];
	          for (int j=n-2; j>=0; --j) 
	          {
	              x[j][i] = b[index[j]][i];
	              for (int k=j+1; k<n; ++k) 
	              {
	                  x[j][i] -= a[index[j]][k]*x[k][i];
	              }
	              x[j][i] /= a[index[j]][j];
	          }
	      }
	      return x;
	  }
	////ChangeCoordSystem
	public double[] WorldToCamera(double[] point) {
		double[] cpoint = new double[3];
		double[][] camM = MatInverse(Transmat(camP,0.0,0.0,0.0,camP[0],camP[1],-1/camP[2]));
		
		cpoint[0] = point[0]*camM[0][0] + point[0]*camM[1][0] + point[0]*camM[2][0] + camM[3][0];
		cpoint[1] = point[1]*camM[0][1] + point[1]*camM[1][1] + point[1]*camM[2][1] + camM[3][1];
		cpoint[2] = point[2]*camM[0][2] + point[2]*camM[1][2] + point[2]*camM[2][2] + camM[3][2];
		
		return cpoint;
	}
	
	public double[] CameraToCanvas(double[] point) {
		double[] cpoint = new double[3];
		cpoint[0] = (point[0]/(1/-point[2]))*zNear;
		cpoint[1] = (point[1]/(1/-point[2]))*zNear;
		cpoint[2] = 1;
		if(point[2]>=0) cpoint[2] = 0;
		
		return cpoint;
	}
	
	public double[] CanvasToNDC(double[] point) {
		double[] spoint = new double[3];
		spoint[0] = (point[0] + (width*.5))/width;
		spoint[1] = (point[1] + (height*.5))/height;
		spoint[2] = point[2];
		System.out.println("1 :" + Arrays.toString(spoint));
		return spoint;
	}
	
	public int[] NDCToRaster(double[] point) {
		int[] rpoint = new int[3];
		rpoint[0] = (int)Math.floor(point[0]*width);
		rpoint[1] = (int)Math.floor((1-point[1])*height);
		rpoint[2] = (int)point[2];
		return rpoint;
	}
	
	public int[] WorldToRaster(double[] point) 
	{
		return NDCToRaster(CanvasToNDC(CameraToCanvas(WorldToCamera(point))));
	}
	////Transforming
	public double[] Transform(double[] point, double xRot, double yRot, double zRot, double xTrans, double yTrans, double zTrans) 
	{
		double[] Tpoint = new double[3];
		Tpoint = Translate(RotateXYZ(point, xRot, yRot, zRot), xTrans, yTrans, zTrans);
		return Tpoint;
	}
	
	public double[] Translate(double[] point, double xTrans, double yTrans, double zTrans) {
		double[] Tpoint = new double[3];
		Tpoint[0] = point[0] + xTrans;
		Tpoint[1] = point[1] + yTrans;
		Tpoint[2] = point[2] + zTrans;
		return Tpoint;
	}
	
	public double[] RotateXYZ(double[] point, double xRot, double yRot, double zRot) {
		double[] pointR = new double[2];
		pointR[0] = (point[0]*(Math.cos(yRot)*Math.sin(zRot))) + (point[1]*(-Math.cos(yRot)*Math.sin(zRot))) + (point[2]*(Math.sin(yRot)));
		pointR[1] = (point[0]*((Math.sin(xRot)*Math.sin(yRot)*Math.cos(zRot) + (Math.cos(xRot)*Math.sin(zRot))))) + (point[1]*((-Math.sin(xRot)*Math.sin(yRot)*Math.sin(zRot) + (Math.cos(xRot)*Math.cos(zRot))))) + (point[2]*(-Math.sin(xRot)*Math.cos(yRot)));
		pointR[2] = (point[0]*((-Math.cos(xRot)*Math.sin(yRot)*Math.cos(zRot) + (Math.sin(xRot)*Math.sin(zRot))))) + (point[1]*((Math.cos(xRot)*Math.sin(yRot)*Math.sin(zRot) + (Math.cos(xRot)*Math.sin(zRot))))) + (point[2]*(Math.cos(xRot)*Math.cos(yRot)));
		
		return pointR;
	}
	
	public static double[][] Transmat(double[] point, double xRot, double yRot, double zRot, double xTrans, double yTrans, double zTrans) {
		double[][] mat = new double[4][4];
		
	    /*  
		mat[0][0] = (point[0]*(Math.cos(yRot)*Math.sin(zRot))); 
		mat[0][1] = (point[1]*(-Math.cos(yRot)*Math.sin(zRot)));
		mat[0][2] = (point[2]*(Math.sin(yRot)));
		mat[0][3] = 0;
		mat[1][0] = (point[0]*((Math.sin(xRot)*Math.sin(yRot)*Math.cos(zRot) + (Math.cos(xRot)*Math.sin(zRot)))));
		mat[1][1] = (point[1]*((-Math.sin(xRot)*Math.sin(yRot)*Math.sin(zRot) + (Math.cos(xRot)*Math.cos(zRot)))));
		mat[1][2] = (point[2]*(-Math.sin(xRot)*Math.cos(yRot)));
		mat[1][3] = 0;
		mat[2][0] = (point[0]*((-Math.cos(xRot)*Math.sin(yRot)*Math.cos(zRot) + (Math.sin(xRot)*Math.sin(zRot)))));
		mat[2][1] = (point[1]*((Math.cos(xRot)*Math.sin(yRot)*Math.sin(zRot) + (Math.cos(xRot)*Math.sin(zRot)))));
		mat[2][2] = (point[2]*(Math.cos(xRot)*Math.cos(yRot)));
		mat[2][3] = 0;
		mat[3][0] = xTrans;
		mat[3][1] = yTrans;
		mat[3][2] = zTrans;
		mat[3][3] = 1;
		*/
		mat[0][0] = ((Math.cos(yRot)*Math.cos(zRot))); 
		mat[0][1] = ((-Math.cos(yRot)*Math.sin(zRot)));
		mat[0][2] = ((Math.sin(yRot)));
		mat[3][0] = 0;
		mat[1][0] = (((Math.sin(xRot)*Math.sin(yRot)*Math.cos(zRot) + (Math.cos(xRot)*Math.sin(zRot)))));
		mat[1][1] = (((-Math.sin(xRot)*Math.sin(yRot)*Math.sin(zRot) + (Math.cos(xRot)*Math.cos(zRot)))));
		mat[1][2] = ((-Math.sin(xRot)*Math.cos(zRot)));
		mat[1][3] = 0;
		mat[2][0] = (((-Math.cos(xRot)*Math.sin(yRot)*Math.cos(zRot) + (Math.sin(xRot)*Math.sin(zRot)))));
		mat[2][1] = (((Math.cos(xRot)*Math.sin(yRot)*Math.sin(zRot) + (Math.cos(zRot)*Math.sin(xRot)))));
		mat[2][2] = ((Math.cos(xRot)*Math.cos(yRot)));
		mat[2][3] = 0;
		mat[3][0] = xTrans;
		mat[3][1] = yTrans;
		mat[3][2] = zTrans;
		mat[3][3] = 1;
		return mat;
	}
	
	

}