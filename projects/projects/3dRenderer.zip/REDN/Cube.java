import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class Cube extends Applet implements Runnable {
  int frameNumber = -1;
  CubeCont run = new CubeCont();
  
  int delay = 100;

  Thread animatorThread;

  boolean frozen = false;

  public void init() {
    
    
    addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        if (frozen) {
          frozen = false;
          start();
        } else {
          frozen = true;
          stop();
        }
      }
    });
  }

  public void start() {
    if (!frozen) {
      if (animatorThread == null) {
        animatorThread = new Thread(this);
      }
      animatorThread.start();
    }
  }

  public void stop() {
    animatorThread = null;
  }

  public void run() {
    Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
    setSize(800,600);
    
    long startTime = System.currentTimeMillis();
    
    Thread currentThread = Thread.currentThread();

    while (currentThread == animatorThread) {
      frameNumber++;

      repaint();

      try {
        startTime += delay;
        Thread.sleep(100);
      } catch (InterruptedException e) {
        break;
      }
    }
  }

  public void paint(Graphics g) {
	  
	  run.stSet(0, 0, 0, 0, 0, 0);
	  
	  for(int i = 0; i<8; i++) {
		  //System.out.println(run.getLine(i)[0]);
		//g.drawLine(run.getLine(i)[0], run.getLine(i)[1], run.getLine(i)[2], run.getLine(i)[3]);
		  g.setColor(Color.BLACK);
		  if(run.getPoint(i)[2] == 1)
		  g.drawRect(run.getPoint(i)[0], run.getPoint(i)[1], 2, 2);
		  else{
			  g.setColor(Color.RED);
			  g.drawRect(run.getPoint(i)[0], run.getPoint(i)[1], 2, 2);
		  }
		  
	}
	  //System.out.println("eee");
      g.drawString("Frame " + frameNumber, 0, 30);
      stop();
  }
}