import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class MadLib1 implements MadLib
{
	private Queue<String> words; //A queue of the words that will fill the blanks of the story
	private Queue<String> wordTypes; //A queue of the type of words in the blanks of the story
	private String story; //The mad-lib story
	
	public MadLib1()
	{
		words = new LinkedList<String>();
		//Summoning forth a demon to save the world
		//The story. What ever is in * is the type of word it represents and is something that gets replaced with a word
		story = "    This is the day. This is the day you save the world from it's horrors. For the past *number greater than one* years, "
				+ "*plural word for an animal* have taken over. They have eaten our *plural of a food*, stole our *plural of an object*, and refused to give things back after"
				+ " \"borrowing\" it. They have ruined everything that humanity has stood for, and this is the day that you change that. "
				+ "You are *name*, and it is July, *number from 1 to 31 inclusive* 22XX, the most satanic time of the year. Your goal is "
				+ "to summon the demon of *plural of an object*, and to hopefully trade your surplus of *plural of an object* for the demon's dedication to the "
				+ "eradication of those *negative adjective* *1*. You honestly wanted to get rid of the *7* anyway. You only got them "
				+ "because you thought that by *verb that ends in ing* them, you could be become more quirky and more likable as result. In the end, "
				+ "it wasn't either, it was just weird and embarrassing. You figure you should start the summoning ritual at this point though, "
				+ "so that's what you do. Of course you're not alone in the ceremony. Since you know next to nothing about summoning "
				+ "beings from other dimensions, you had to contact a few professional *plural of an occupation (like \"firemen\" or \"astronauts\")*. You figured that if you tryed to "
				+ "do this whole summoning thing on your own, you would end up summoning something useless like a *creature* or bringing back to life an "
				+ "evil *noun*. There are only *any integer number greater than 0* *12* with you, since *12* don't really come all that cheap, and you aren't really all that wealthy. You don't know their names, but "
				+ "you're pretty sure that one is just a homeless person in a *12* *clothing type*. The summoning seems to be almost... "
				+ "oh! Well, I guess that's the demon of *6* right there. Somehow you expected him to be more... evil looking. While "
				+ "you're probably not the expert on what \"evilness\" looks like, you're pretty sure it doesn't come in the form of a flying *color* "
				+ "goblin wearing *plural of type of clothing*, and you're also pretty sure you shouldn't voice your thoughts on this in his presense. You're not really sure how you're supposed to indroduce "
				+ "yourself to a powerful creature of the underworld, but you manage to say *thing that you say when you meet someone*. "
				+ "The demon, who is apparently pretty enthusiastic about being brought to the mortal plane, responds with a casual yet "
				+ "formal hello, and offers a handshake. Of course you comply. Last time you heard of someone who disrespected a powerful being "
				+ "was when you heard that one your town's messengers said \"*phrase*\" to a *mythical creature*, of course, this "
				+ "was possibly the most offensive thing you could say to a *25*. This ultimately led to him staying for weeks in the medical building after the incedent. You decide to your self that cultural differences are complicated. "
				+ "The demon asks you why he has been summoned, specifically in a what-can-I-do-for-you sort of way. You explain how *1* have "
				+ "ruined society in almost every way imaginable, that I and quite a few others are kinda peeved off by the whole thing, and that "
				+ "I was hoping that, because *6* are known as the natural enemy of *1*, you could sort of like, exterminate them all, if that's "
				+ "a thing you can do, please? The demon assures you that you are in good hands. He tells you that, not only is that job well within his "
				+ "physical capabilities, but because the job specifically involves his special power of *6*, you will get a 20% discount "
				+ "on the price of the deal! Price? You become worried at the idea that you came all this way just to not have the right currency, "
				+ "or any for that matter, other than these two *name of a thing*s you were planning to use to buy some *drink* later. You hesitantly "
				+ "tell the demon that you were just planning to trade your *7* for the job, and that you don't really have much money otherwise. "
				+ "The demon suddenly leaps with joy. Apparently *7* are his favorite thing in the whole underworld, and assures you that, even though it is technically "
				+ "against his code of conduct for the company he works for, he will make an exeption just this once. Your *7* suddenly disapear, supposedly"
				+ " to the depths of the underworld. You shake hands with the demon and he tells you that he'll get started right away. "
				+ "You just saved the world!"; 
		wordTypes = listOfTypes();
	}
	
	public void addWord(String s) //Adds the word to the list of words as the word that will fill the next blank of the story
	{
		words.add(s);
	}
	
	public String getNextType() //Get's the type of word that should fill the next blank
	{
		return wordTypes.remove();
	}
	
	public String putInLines(String s) //Automatically puts \n after 60 charachters and on a space, and returns the string
	{
		int letUntilLine  = 0;
		int index = 0;
		int lines = 0;
		String output = s + "";
		while(index<output.length())
		{
			
			if(letUntilLine >= 60 && output.charAt(index) == ' ') //If there has been 60 charachters and the current index is a space
			{													  //then put a \n in place of the space
				output = output.substring(0, index) + "\n" + output.substring(index+1, output.length());
				letUntilLine = 0;
				lines++;
			}
			else
			{
				letUntilLine++;
			}
			index++;
		}
		return output;
	}
	
	public int numOfBlanks() //Counts and returns the number of blanks in the story
	{
		String s = story + "";
		int count = 0;
		for(int i = 0; i<s.length(); i++) //For all of the chars in the story
		{ 								  //increment count by 1 for each pair of '*'
			if(s.charAt(i) == '*') 
			{
				count++;
				s = s.substring(0,i) + s.substring(i+1, s.length());
				s = s.substring(0, i) + s.substring(s.indexOf('*')+1, s.length());
			}
		}
		return count;
	}
	
	public Queue<String> listOfTypes() //Returns a Queue of the list of types of words that should fill the blanks of the story
	{
		String s = story + "";
		Queue<String> queue = new LinkedList<String>();
		for(int i = 0; i<s.length(); i++)
		{
			if(s.charAt(i) == '*')
			{
				s = s.substring(0,i) + s.substring(i+1, s.length());
				queue.add(s.substring(i,s.indexOf('*')));
				s = s.substring(0, i) + s.substring(s.indexOf('*')+1, s.length());
			}
		}
		return queue;
	}
	
	public String toString() //Returns the finished story
	{
		String s = story + ""; //Stores the returned value of the story with it's blanks filled
		int blankIndex = 0; //Stores the index of the next blank
		String after = ""; //Stores the stuff from the story that comes after the blank
		if(numOfBlanks() != words.size()) return "Error: numOfBlanks() != words.size()"; //Return error if the number of blanks does not equal the amount of imputted words
		for(int i = 0; i<numOfBlanks(); i++) //This for loop is what fills the blanks with the words from the words Queue
		{
			blankIndex = s.indexOf('*');
			after = (s.substring(blankIndex+1,s.length()));
			s = s.substring(0,blankIndex) + words.remove() + after.substring(after.indexOf('*')+1, after.length());
		}
		s = putInLines(s);
		return s;
	}
	
}


