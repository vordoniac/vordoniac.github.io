import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class MadLib2 implements MadLib
{
	private Queue<String> words; //A queue of the words that will fill the blanks of the story
	private Queue<String> wordTypes; //A queue of the type of words in the blanks of the story
	private String story; //The mad-lib story
	
	public MadLib2()
	{
		words = new LinkedList<String>();
		//Winning the froggy sport
		//The story. What ever is in * is the type of word it represents and is something that gets replaced with a word
		story = "    So *name* was at his house. Despite this ordinary and not very exciting setting, *0* was on a mission. His "
				+ "mission was to win the *sport* competition. Well, for his frog *name* to win the *2* competition. Every year, "
				+ "this compitition is held to see which frog is the most strongest, agile, and intelligent of them all. *3* always managed "
				+ "to get third or second place, but *0* was determined this year to train *3* to victory. Now, *3* was strong enough to jump "
				+ "100 *unit of distance*, fast enough to competently race a *animal*, and smart enough to make you question the moral implications of having *3* as a pet in "
				+ "the first place. Honestly, the only reason *0* isn't afraid of *3* right now is because *3* likes *0*, and y'know, the "
				+ "fact that frogs are just completely non-threatening in general, regardless of the amount of training they've done. Anyway, the competition "
				+ "is just starting. First is the *verb that ends in ing* section. This part always scares *0*, since *16* has always been really hard "
				+ "for *3*. Professional frog trainers always said to *0* that the best way to train for this is to have your frog do the "
				+ "*16* while they are *verb that ends in ing*, but this never really worked for *3* because he had an irrational fear of "
				+ "*22* ever since *0* went to *location*. People always ask *0* what happened at *location*, but *0* never says anything on it "
				+ "other than it was \"actually kind of really upsetting and I don't even remember most of it\". Somehow though, it looks like "
				+ "*3* managed to score *number like \"8th\" or \"1st\" or \"2nd\". Y'know, something like that* place in the event. But that's "
				+ "only the rank for the *16* section. The final, and most important rank, is a complex mathematical result from what a frog scores in this first section "
				+ "and in the next two. Next up though is the *verb that ends in ing* section. While this section is often known as the hardest of all the "
				+ "sections, *3* happens to actually be really good at it. *3* was always proud of having this skill. Unsuprisingly, *0*'s frog ranked first place in the section. Now "
				+ "*0* was getting tense. *0* knew that they had a chance this time. This was it. The last section. In this section, the frogs "
				+ "had to stay perfectly still for as long as possible. Most frogs only lasted for *number* minutes before moving. In the end, "
				+ "*3* managed to be the fourth last to move, which meant getting 4th in the section. *0* realizes that that rank might just be "
				+ "enough to get *3* into first place overall. As *0* awaits the final anouncement with *3*, *0* notices something strange "
				+ "about *3*. It took a while to notice, but it turns out that the frog that had been participating in the competition wasn't "
				+ "*3*! It instead was *0*'s other pet frog *name*! At about this moment of realization, it was announced that \"*3*\" had won "
				+ "first place, as well as all the other frogs. It turns out that the judges weren't really paying attention and as a comprimise, they "
				+ "just decided to give everyone first place. *0* considers this a partial victory and returns home."; 
		wordTypes = listOfTypes();
	}
	
	public void addWord(String s) //Adds the word to the list of words as the word that will fill the next blank of the story
	{
		words.add(s);
	}
	
	public String getNextType() //Get's the type of word that should fill the next blank
	{
		return wordTypes.remove();
	}
	
	public String putInLines(String s) //Automatically puts \n after 60 charachters and on a space, and returns the string
	{
		int letUntilLine  = 0;
		int index = 0;
		int lines = 0;
		String output = s + "";
		while(index<output.length())
		{
			
			if(letUntilLine >= 60 && output.charAt(index) == ' ') //If there has been 60 charachters and the current index is a space
			{													  //then put a \n in place of the space
				output = output.substring(0, index) + "\n" + output.substring(index+1, output.length());
				letUntilLine = 0;
				lines++;
			}
			else
			{
				letUntilLine++;
			}
			index++;
		}
		return output;
	}
	
	public int numOfBlanks() //Counts and returns the number of blanks in the story
	{
		String s = story + "";
		int count = 0;
		for(int i = 0; i<s.length(); i++) //For all of the chars in the story
		{ 								  //increment count by 1 for each pair of '*'
			if(s.charAt(i) == '*') 
			{
				count++;
				s = s.substring(0,i) + s.substring(i+1, s.length());
				s = s.substring(0, i) + s.substring(s.indexOf('*')+1, s.length());
			}
		}
		return count;
	}
	
	public Queue<String> listOfTypes() //Returns a Queue of the list of types of words that should fill the blanks of the story
	{
		String s = story + "";
		Queue<String> queue = new LinkedList<String>();
		for(int i = 0; i<s.length(); i++)
		{
			if(s.charAt(i) == '*')
			{
				s = s.substring(0,i) + s.substring(i+1, s.length());
				queue.add(s.substring(i,s.indexOf('*')));
				s = s.substring(0, i) + s.substring(s.indexOf('*')+1, s.length());
			}
		}
		return queue;
	}
	
	public String toString() //Returns the finished story
	{
		String s = story + ""; //Stores the returned value of the story with it's blanks filled
		int blankIndex = 0; //Stores the index of the next blank
		String after = ""; //Stores the stuff from the story that comes after the blank
		if(numOfBlanks() != words.size()) return "Error: numOfBlanks() != words.size()"; //Return error if the number of blanks does not equal the amount of imputted words
		for(int i = 0; i<numOfBlanks(); i++) //This for loop is what fills the blanks with the words from the words Queue
		{
			blankIndex = s.indexOf('*');
			after = (s.substring(blankIndex+1,s.length()));
			s = s.substring(0,blankIndex) + words.remove() + after.substring(after.indexOf('*')+1, after.length());
		}
		s = putInLines(s);
		return s;
	}
	
}


