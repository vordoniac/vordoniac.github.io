import java.util.Queue;

public interface MadLib
{
   String getNextType();
   void addWord(String s);
   String putInLines(String s);
   int numOfBlanks();
   Queue<String> listOfTypes();
   String toString();
}