import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class MadLib3 implements MadLib
{
	private Queue<String> words; //A queue of the words that will fill the blanks of the story
	private Queue<String> wordTypes; //A queue of the type of words in the blanks of the story
	private String story; //The mad-lib story
	
	public MadLib3()
	{
		words = new LinkedList<String>();
		//Catching the largest rat
		//The story. What ever is in * is the type of word it represents and is something that gets replaced with a word
		story = "    You are in your basement. Under normal circumstances, you would be adding to your vast *thing* collection that you "
				+ "have stored down here, questioning your sanity as a functioning human being every time you acknowledge it. But these "
				+ "are not normal circumstances, at least you don't think they are. Your not completely sure how \"normal\" it is for a person to have a "
				+ "problem like this, but you assume you are the only person on the planet right now that's attempting to kill a *adjective* rat the "
				+ "size of a *thing* with nothing but a *weapon of choice* as a weapon and a *defense of choice* as your defense. You would call a professional *1* rat exterminator, "
				+ "that is, if the rat wasn't the size of *2*. The only people that can handle a rat that size are *plural of a type of person* and "
				+ "*plural of a type of person*, and no amount of lemonade stands could possibly make hiring them affordable. So you decided the "
				+ "best course of action would be to take the rat on in a one on one duel. You figure that placing a trap would probably "
				+ "be more practical at this point, but that wouldn't be nearly as exciting or cool. You take a few steps foward, and you spot the *1*, *2* sized rat, just as it spots you. You both stand still, for a "
				+ "decidedly awkward amount of time, *number* minute(s) to be exact. Yeah, while it is kinda cool to have an acute sense of time, it's "
				+ "rarely practical. You would rather have the ability to *cool thing to do (verb)*, which would be both cool and applicable. Because you've gotten pretty bored of this "
				+ "waiting, you decide to strike first. You go for the *name of a cool fighting move*, which actually just involves hitting the "
				+ "opponent with something and then saying something extremely demotivational to them. After striking him in the head with your *3*, you decide to "
				+ "say, \"*thing you say to someone else to demotivate them*\". After preforming the move, you realize that what you said probably sounded like a million times better in your head, "
				+ "but you act like it was super rad and not embarrassing in the slightest. "
				+ "The rat looks terrified. It asks you to please don't hit him I'm so sorry I don't know what I did I'll leave you alone if "
				+ "you want. You say that you would like him to leave your house, forever, please. The rat ran away. Well, even if the victory "
				+ "wasn't as dramatic as you hoped, it was victory none-the-less. Also, yeah, the rat could talk. That was weird."; 
		wordTypes = listOfTypes();
	}
	
	public void addWord(String s) //Adds the word to the list of words as the word that will fill the next blank of the story
	{
		words.add(s);
	}
	
	public String getNextType() //Get's the type of word that should fill the next blank
	{
		return wordTypes.remove();
	}
	
	public String putInLines(String s) //Automatically puts \n after 60 charachters and on a space, and returns the string
	{
		int letUntilLine  = 0;
		int index = 0;
		int lines = 0;
		String output = s + "";
		while(index<output.length())
		{
			
			if(letUntilLine >= 60 && output.charAt(index) == ' ') //If there has been 60 charachters and the current index is a space
			{													  //then put a \n in place of the space
				output = output.substring(0, index) + "\n" + output.substring(index+1, output.length());
				letUntilLine = 0;
				lines++;
			}
			else
			{
				letUntilLine++;
			}
			index++;
		}
		return output;
	}
	
	public int numOfBlanks() //Counts and returns the number of blanks in the story
	{
		String s = story + "";
		int count = 0;
		for(int i = 0; i<s.length(); i++) //For all of the chars in the story
		{ 								  //increment count by 1 for each pair of '*'
			if(s.charAt(i) == '*') 
			{
				count++;
				s = s.substring(0,i) + s.substring(i+1, s.length());
				s = s.substring(0, i) + s.substring(s.indexOf('*')+1, s.length());
			}
		}
		return count;
	}
	
	public Queue<String> listOfTypes() //Returns a Queue of the list of types of words that should fill the blanks of the story
	{
		String s = story + "";
		Queue<String> queue = new LinkedList<String>();
		for(int i = 0; i<s.length(); i++)
		{
			if(s.charAt(i) == '*')
			{
				s = s.substring(0,i) + s.substring(i+1, s.length());
				queue.add(s.substring(i,s.indexOf('*')));
				s = s.substring(0, i) + s.substring(s.indexOf('*')+1, s.length());
			}
		}
		return queue;
	}
	
	public String toString() //Returns the finished story
	{
		String s = story + ""; //Stores the returned value of the story with it's blanks filled
		int blankIndex = 0; //Stores the index of the next blank
		String after = ""; //Stores the stuff from the story that comes after the blank
		if(numOfBlanks() != words.size()) return "Error: numOfBlanks() != words.size()"; //Return error if the number of blanks does not equal the amount of imputted words
		for(int i = 0; i<numOfBlanks(); i++) //This for loop is what fills the blanks with the words from the words Queue
		{
			blankIndex = s.indexOf('*');
			after = (s.substring(blankIndex+1,s.length()));
			s = s.substring(0,blankIndex) + words.remove() + after.substring(after.indexOf('*')+1, after.length());
		}
		s = putInLines(s);
		return s;
	}
	
}


