import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class MadLibRunner
{
	public static void main( String args[] )
	{
		MadLib t = new MadLib1();
		String aOrAn = "a";
		String nextWordType = "";
		String input = "";
		ArrayList<String> inputs = new ArrayList<String>();
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Which madlib would you like to do? [Enter 1,2, or 3]");
		input = keyboard.nextLine();
		while(true)
		{
		if(input.equals("1"))
		{
			t = new MadLib1();
			break;
		}
		else if(input.equals("2"))
		{
			t = new MadLib2();
			break;
		}
		else if(input.equals("3"))
		{
			t = new MadLib3();
			break;
		}
		System.out.println("Which madlib would you like to do? And, yeah, do what this says -> [Enter 1,2, or 3]");
		input = keyboard.nextLine();
		}
		for(int i = 0; i<t.numOfBlanks(); i++)
		{
			nextWordType = t.getNextType();
			if(isNumber(nextWordType))
			{
				t.addWord(inputs.get(Integer.parseInt(nextWordType)));
				inputs.add(inputs.get(Integer.parseInt(nextWordType)));
			}
			else
			{
				if(isVowel(nextWordType.charAt(0))) aOrAn = "an";
				else
				{
					aOrAn = "a";
				}
				System.out.print("Give " + aOrAn + " " + nextWordType + ": ");
				input = keyboard.nextLine();
				inputs.add(input);
				t.addWord(input);
			}
			
		}
		for(int i = 0; i < inputs.size(); i++)
		{
			if(inputs.get(i).equals("unicorn")) System.out.println(i);
		}
		System.out.println("\nAlright here's the thing: \n");
		System.out.println(t.toString());
	}
	
	public static boolean isVowel(char c) //Pre-condition: Char is NOT capital.
	{
		if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') return true;
		return false;
	}
	
	public static boolean isNumber(String s)
	{
		for(int i = 0; i<s.length(); i++)
		{
			if(!(s.charAt(i) >= 48 && s.charAt(i) <= 57)) return false;
		}
		return true;
	}
}